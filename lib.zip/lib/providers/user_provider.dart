import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:practice_flutter/tarea1profe/models/models.dart';

class UserProvider extends ChangeNotifier {
  String initialUrl = 'localhost:3000';
  UserProvider() {
    //getUsers();
    //getUser(1);
    //createUser();
    //deleteUser(1);
    updateUser(1);
  }

  getUsers() async {
    Uri urlLol = Uri.http(initialUrl, 'users');
    print('------------');
    var response = await http.get(urlLol);

    print(response.body);
  }

  getUser(int id) async {
    Uri urlLol = Uri.http(
      initialUrl,
      'users/$id',
    );
    var response = await http.get(urlLol);
    print('------useId=$id----');
    print(response.body);
  }

  createUser() async {
    Uri urlLol = Uri.http(initialUrl, 'users');

    var res = await http.post(urlLol,
        body: jsonEncode(
          <String, dynamic>{
            'bloodType': {'blodType': 1},
            'roles': ["ADMIN", "STUDENT"],
            'password': 'sikdysdtsudt',
            'email': 'andsrk222@gmail.com',
            'name': 'asddsdhsd',
            'username': 'andersk2',
            'lastname': 'sodrrlal'
          },
        ),
        headers: <String, String>{'Content-Type': 'application/json'});
    print(res.body);

    //getUsers();
  }

  updateUser(id) async {
    Uri urlLol = Uri.http(initialUrl, 'users/$id');
    var res = await http.put(urlLol,
        body: jsonEncode(
          <String, dynamic>{
            "name": "Juan",
            "lastname": "Perez",
            "birthdate": "1990-12-04",
            "email": "manue@gmail.com"
          },
        ),
        headers: <String, String>{'Content-Type': 'application/json'});

    print(res.body);
  }

  deleteUser(int id) async {
    Uri urlLol = Uri.http(
      initialUrl,
      'users/$id',
    );
    var res = await http.delete(urlLol);
    print(res.body);
  }
}
