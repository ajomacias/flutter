class Catalogo {
  int? catalogo;
  String? name;
}
