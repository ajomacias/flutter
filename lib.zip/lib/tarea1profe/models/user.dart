import 'package:practice_flutter/tarea1profe/models/blood.dart';

class User {
  User(
      {this.id,
      this.createdAt,
      this.deletedAt,
      this.roles,
      this.bloodType,
      this.email,
      this.lastname,
      this.name,
      this.password,
      this.updatedAt,
      this.username});
  int? id;
  String? username;
  String? email;
  String? name;
  String? lastname;
  String? password;
  Blood? bloodType;
  DateTime? createdAt;
  DateTime? updatedAt;
  DateTime? deletedAt;
  List<String>? roles;
}
