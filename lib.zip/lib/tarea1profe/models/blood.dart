class Blood {
  Blood({this.blodType});
  int? blodType;
}
